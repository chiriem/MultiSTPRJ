package kopo.poly.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@Data
@Getter
@Setter
public class ScheduleDTO {

    String year;
    String month;
    String date;
    String value;
    String db_startDate;
    String db_endDate;

    String user_seq;
    String user_id;

}