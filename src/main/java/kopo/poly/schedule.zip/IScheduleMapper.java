package kopo.poly.persistance.mongodb;

import kopo.poly.dto.ScheduleDTO;

public interface IScheduleMapper {

    /**
     * 회원 가입하기 (회원정보 등록하기)
     *
     * @param pDTO 저장할 정보
     * @param colNm 저장할 컬랙션 이름
     * @return 저장 성공 여부
     * @throws Exception
     */
    int insertUserSchedule(ScheduleDTO pDTO, String colNm) throws Exception;

    int updateUserSchedule(ScheduleDTO pDTO, String colNm) throws Exception;

    int deleteUserSchedule(ScheduleDTO pDTO, String colNm) throws Exception;

}