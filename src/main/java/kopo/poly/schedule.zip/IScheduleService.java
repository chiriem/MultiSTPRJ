package kopo.poly.service;

import kopo.poly.dto.ScheduleDTO;

public interface IScheduleService {

    /**
     * 회원 가입하기 (회원정보 등록하기)
     *
     * @param pDTO 저장할 정보
     * @param colNm 참조할 컬렉션 이름
     * @return 저장 성공 여부
     * @throws Exception
     */
    int insertUserSchedule(ScheduleDTO pDTO, String colNm) throws Exception;

    int updateUserSchedule(ScheduleDTO pDTO, String colNm) throws Exception;

    int deleteUserSchedule(ScheduleDTO pDTO, String colNm) throws Exception;
}